-- ============================================================
-- FDB System | fdb-shops | client/client.lua
-- Core Client Logic (Spawning stations, handling interactions)
-- ============================================================

local FDBCore = exports['fdb-core']:GetCoreObject()
local fdbLibs = exports['fdb-libs']
local resourceName = GetCurrentResourceName()
lib.locale()

local spawnedEntities = {}
local shopStations = {}

-- Load Stations from server on player load
RegisterNetEvent('fdb-core:client:PlayerLoaded', function()
    fdbLibs:TriggerServerCallbackAsync('fdb-shops:server:getStations', function(stations)
        shopStations = stations
        InitializeStations()
    end)
end)

-- Temporary fallback for restart script
CreateThread(function()
    Wait(2000)
    if LocalPlayer.state.isLoggedIn then
        fdbLibs:TriggerServerCallbackAsync('fdb-shops:server:getStations', function(stations)
            shopStations = stations
            InitializeStations()
        end)
    end
end)

function InitializeStations()
    -- Cleanup previous
    for _, entity in pairs(spawnedEntities) do
        if DoesEntityExist(entity) then DeleteEntity(entity) end
    end
    spawnedEntities = {}

    for _, station in ipairs(shopStations) do
        -- 1. Create Zone / Interaction Point using fdb-libs
        fdbLibs:CreateZone('shop_station_' .. station.id, vec3(station.position.x, station.position.y, station.position.z), 2.0, {
            drawMarker = (station.type ~= 'npc'), -- Only draw marker if it's not an NPC
            showPrompt = true,
            promptText = GetStationPrompt(station.type),
            onKeyPress = function()
                InteractWithStation(station)
            end
        })

        -- 2. Spawn Visuals (NPCs or Props)
        if station.type == 'npc' and station.npc_model then
            SpawnStationNPC(station)
        elseif station.prop_model then
            SpawnStationProp(station)
        end
    end
end

function GetStationPrompt(stationType)
    local prompts = {
        ['registradora'] = 'Abrir Registradora',
        ['bau'] = 'Abrir Estoque',
        ['craft'] = 'Produzir Itens',
        ['venda'] = 'Abrir Catálogo',
        ['npc'] = 'Falar',
        ['supply_board'] = 'Quadro de Entregas'
    }
    return prompts[stationType] or 'Interagir'
end

function SpawnStationNPC(station)
    local model = station.npc_model
    local coords = station.position
    
    lib.requestModel(model, 5000)
    if not HasModelLoaded(joaat(model)) then return end

    local npc = CreatePed(model, coords.x, coords.y, coords.z - 1.0, station.npc_heading or 0.0, false, false, false, false)
    if npc and npc ~= 0 then
        Citizen.InvokeNative(0x283978A15512B2FE, npc, true)
        SetEntityNoCollisionEntity(npc, PlayerPedId(), false)
        SetEntityCanBeDamaged(npc, false)
        SetEntityInvincible(npc, true)
        FreezeEntityPosition(npc, true)

        if station.animation_name then
            TaskStartScenarioInPlace(npc, joaat(station.animation_name), -1, true, false, false, false)
        end

        spawnedEntities['npc_' .. station.id] = npc
    end
end

function SpawnStationProp(station)
    local model = station.prop_model
    local coords = station.position
    
    lib.requestModel(model, 5000)
    if not HasModelLoaded(joaat(model)) then return end

    local prop = CreateObject(joaat(model), coords.x, coords.y, coords.z - 1.0, false, false, false)
    if prop and prop ~= 0 then
        SetEntityRotation(prop, 0.0, 0.0, station.npc_heading or 0.0, 2, true)
        FreezeEntityPosition(prop, true)
        spawnedEntities['prop_' .. station.id] = prop
    end
end

function InteractWithStation(station)
    if station.type == 'npc' or station.type == 'venda' then
        -- Open Shop Buy Menu
        TriggerServerEvent('fdb-shops:server:openstore', station.shop_id)

    elseif station.type == 'registradora' then
        -- Open Owner Menu (NUI)
        fdbLibs:TriggerServerCallbackAsync('fdb-shops:server:requestOwnerMenu', function(response)
            if response and response.success then
                SetNuiFocus(true, true)
                SendNUIMessage({
                    action = 'openOwnerMenu',
                    shopId = station.shop_id,
                    shopData = response.shopData,
                    permissions = response.permissions
                })
            else
                fdbLibs:Notify('Acesso Negado', 'error', 3000)
            end
        end, station.shop_id)

    elseif station.type == 'bau' then
        -- Open Physical Stash
        -- Verify permissions first
        fdbLibs:TriggerServerCallbackAsync('fdb-shops:server:requestOwnerMenu', function(response)
            if response and response.success and response.permissions.repor_estoque then
                TriggerServerEvent('fdb-shops:server:openStash', station.shop_id)
            else
                fdbLibs:Notify('Você não tem acesso a este estoque', 'error', 3000)
            end
        end, station.shop_id)

    elseif station.type == 'craft' then
        -- Open Crafting Menu (Future Phase 2)
        fdbLibs:Notify('Sistema de craft em desenvolvimento', 'info', 3000)
    
    elseif station.type == 'supply_board' then
        -- Open Supply Board (Future Phase 3)
        fdbLibs:Notify('Nenhuma entrega disponível no momento', 'info', 3000)
    end
end

-- ==========================================
-- NUI Callbacks
-- ==========================================

RegisterNUICallback('close', function(data, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)

RegisterNUICallback('withdraw', function(data, cb)
    TriggerServerEvent('fdb-shops:server:withdrawCash', data.shopId, data.amount)
    cb('ok')
end)

RegisterNUICallback('deposit', function(data, cb)
    TriggerServerEvent('fdb-shops:server:depositCash', data.shopId, data.amount)
    cb('ok')
end)

RegisterNUICallback('updateVariation', function(data, cb)
    TriggerServerEvent('fdb-shops:server:updatePriceVariation', data.shopId, data.variation)
    cb('ok')
end)

-- Cleanup on resource stop
AddEventHandler('onResourceStop', function(resName)
    if resName == resourceName then
        for _, entity in pairs(spawnedEntities) do
            if DoesEntityExist(entity) then DeleteEntity(entity) end
        end
    end
end)
