  {
    id = "fdb",
    name = "FDB Core",
    folder = "fdb-core",
    matchResources = { "fdb-core" },
  },
