  {
    id = "fdb",
    name = "FDB Inventory",
    folder = "fdb-inventory",
    matchResources = { "fdb-inventory" },
  },
